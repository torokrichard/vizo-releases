"""Casa in Brasov ca aplicatie Windows: fereastra proprie (WebView2), iconita in bara de activitati si in tray.

Inchiderea ferestrei NU opreste aplicatia: ramane langa ceas si cauta singura la fiecare 3 ore.
Iesi din meniul iconitei din tray ("Inchide de tot"). Cu --tray porneste ascunsa (la pornirea Windows).
"""
import ctypes
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

HERE = Path(__file__).parent
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Vizo.App")
sys.path.insert(0, str(HERE))

# --colecteaza <judet> <full|fast>: procesul de fundal care cauta un alt judet (pornit de app.judete_loop), fara fereastra.
# Judetul trebuie stiut INAINTE de import app (orase.py alege dosarul de date la import).
_COL = sys.argv[sys.argv.index("--colecteaza") + 1:] if "--colecteaza" in sys.argv else None
if _COL:
    import os as _os
    _os.environ["VIZO_CITY"] = _COL[0]

import app  # noqa: E402

if _COL:
    try:
        app.headless_collect(_COL[1] if len(_COL) > 1 else "full")
    finally:
        sys.exit(0)
import webview  # noqa: E402

TITLE = "Vizo"


def already_running(timeout=5):
    """5 s, nu 2 (24.11.2026): cu PC-ul incarcat (colectari + GPU) raspunsul putea trece de 2 s, copia noua credea ca nu
    ruleaza nimic, incerca portul ocupat si se inchidea fara niciun semn ("aplicatia nu se deschide")."""
    try:
        urllib.request.urlopen(app.URL + "api/status", timeout=timeout)
        return True
    except Exception:
        return False


def poke_running_copy():
    """Copia care ruleaza deja (in tray) isi deschide fereastra. Procesul pornit de un click are voie sa aduca o fereastra
    in fata; copia din tray nu are, asa ca ii dam voie (AllowSetForegroundWindow) inainte s-o rugam. Fara asta fereastra
    se deschidea in spatele celorlalte si parea ca nu s-a intamplat nimic."""
    try:
        ctypes.windll.user32.AllowSetForegroundWindow(-1)   # ASFW_ANY
    except Exception:
        pass
    try:
        urllib.request.urlopen(urllib.request.Request(app.URL + "api/show", data=b"{}", method="POST"), timeout=8)
    except Exception:
        webbrowser.open(app.URL)


def bring_to_front():
    u = ctypes.windll.user32
    h = u.FindWindowW(None, TITLE)
    if h:
        u.ShowWindow(h, 9)   # SW_RESTORE
        u.SetForegroundWindow(h)


def set_icon():
    u = ctypes.windll.user32
    ico = str(HERE / "vizo.ico")
    for _ in range(60):
        h = u.FindWindowW(None, TITLE)
        if h:
            u.SendMessageW(h, 0x80, 1, u.LoadImageW(None, ico, 1, 256, 256, 0x10))
            u.SendMessageW(h, 0x80, 0, u.LoadImageW(None, ico, 1, 32, 32, 0x10))
            return
        time.sleep(0.1)


BAR = {"bg": (244, 243, 239), "fg": (17, 17, 17), "dark": False}   # ultima culoare ceruta de pagina deschisa


def set_titlebar(bg=None, fg=None, dark=None):
    """Bara de titlu Windows in culorile paginii (Windows 11: fundal, text, chenar; tema inchisa pentru butoane),
    ca sa nu mai fie o fasie gri deasupra aplicatiei. Pe Windows 10 atributele de culoare lipsesc: ramane bara standard."""
    if bg is not None:
        BAR.update(bg=bg, fg=fg, dark=dark)
    h = ctypes.windll.user32.FindWindowW(None, TITLE)
    if not h:
        return
    ref = lambda c: c[0] | (c[1] << 8) | (c[2] << 16)   # COLORREF = 0x00BBGGRR
    for attr, val in ((20, 1 if BAR["dark"] else 0), (35, ref(BAR["bg"])), (36, ref(BAR["fg"])), (34, ref(BAR["bg"]))):
        v = ctypes.c_int(val)
        try:
            ctypes.windll.dwmapi.DwmSetWindowAttribute(h, attr, ctypes.byref(v), ctypes.sizeof(v))
        except Exception:
            pass


def relaunch(geom=None):
    """Schimbarea judetului (23.11.2026): datele si modelul sunt pe judet, asa ca aplicatia porneste din nou pe el.
    Copia noua asteapta (--dupa-restart) pana se elibereaza portul. 24.11.2026: primeste si locul si marimea ferestrei
    (--geom), ca sa se deschida exact peste cea veche."""
    import subprocess
    cmd = [sys.executable] if getattr(sys, "frozen", False) else [sys.executable, str(Path(__file__).resolve())]
    extra = ["--geom", ",".join(str(int(v)) for v in geom)] if geom else []
    subprocess.Popen(cmd + ["--dupa-restart"] + extra, cwd=str(HERE), close_fds=True)


def other_window_up(timeout=90):
    """Asteapta fereastra vizibila "Vizo" a copiei noi (alt proces decat acesta)."""
    from ctypes import wintypes
    u, me = ctypes.windll.user32, ctypes.windll.kernel32.GetCurrentProcessId()
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    end = time.time() + timeout
    while time.time() < end:
        found = []

        def cb(h, _):
            pid = wintypes.DWORD()
            u.GetWindowThreadProcessId(h, ctypes.byref(pid))
            if pid.value != me and u.IsWindowVisible(h):
                b = ctypes.create_unicode_buffer(64)
                u.GetWindowTextW(h, b, 64)
                if b.value == TITLE:
                    found.append(h)
            return True
        u.EnumWindows(proc(cb), 0)
        if found:
            return True
        time.sleep(0.3)
    return False


def parse_geom():
    try:
        x, y, wd, ht, z = (int(v) for v in sys.argv[sys.argv.index("--geom") + 1].split(","))
        return {"x": x, "y": y, "width": max(wd, 420), "height": max(ht, 600), "maximized": bool(z)}
    except Exception:
        return {}


def main():
    if "--dupa-restart" in sys.argv:
        for _ in range(60):
            if not already_running():
                break
            time.sleep(0.5)
    if already_running():
        # o copie ruleaza deja (in tray): doar deschidem fereastra ei
        poke_running_copy()
        return
    try:
        srv = app.start()
    except OSError:
        # portul e ocupat: o copie ruleaza, doar ca a raspuns prea incet mai sus. Nu ne inchidem fara semn.
        if already_running(timeout=20):
            poke_running_copy()
        else:
            webbrowser.open(app.URL)
        return
    hidden = "--tray" in sys.argv
    size = {"width": 1440, "height": 920}
    size.update(parse_geom())
    w = webview.create_window(TITLE, app.URL, min_size=(420, 600), background_color="#F4F3EF", text_select=True,
                              zoomable=True, hidden=hidden, **size)
    state = {"quit": False}

    def show():
        w.show(); w.restore()
        bring_to_front()

    def on_closing():
        if state["quit"]:
            return True
        w.hide()
        tip("Vizo rulează în continuare", "Caută singur la fiecare 20 de minute. Îl găsești lângă ceas.")
        return False

    w.events.closing += on_closing
    w.events.shown += lambda: threading.Thread(target=set_icon, daemon=True).start()
    w.events.shown += lambda: set_titlebar()
    app.SHOW[:] = [show]
    app.WINBAR[:] = [set_titlebar]

    import pystray
    from PIL import Image

    def quit_all(*_):
        state["quit"] = True
        try:
            tray.stop()
        except Exception:
            pass
        # 24.11.2026: si fereastra ascunsa Imobiliare. Cat traia ea, webview.start() nu se termina, procesul ramanea
        # fara fereastra dar cu portul ocupat, iar copia pornita pe judetul nou nu se mai deschidea.
        try:
            imo.destroy()
        except Exception:
            pass
        w.destroy()

    def restart(*_):
        """24.11.2026 (schimbarea judetului inchidea aplicatia, enervant): fereastra veche ramane deschisa cu
        mesajul "Vizo porneste pe judetul ..." pana apare cea noua, in acelasi loc si la aceeasi marime; abia apoi
        dispare. Serverul vechi elibereaza portul intai, ca noua copie sa porneasca imediat."""
        geom = None
        try:
            h = ctypes.windll.user32.FindWindowW(None, TITLE)
            zoomed = bool(h and ctypes.windll.user32.IsZoomed(h))
            if w.width and w.height and w.x is not None:
                geom = (w.x, w.y, w.width, w.height, 1 if zoomed else 0)
        except Exception:
            pass
        try:
            srv.shutdown(); srv.server_close()
        except Exception:
            pass
        relaunch(geom)
        other_window_up()   # copia noua porneste mereu cu fereastra (fara --tray); dupa 90 s ne inchidem oricum
        quit_all()

    app.RESTART[:] = [restart]

    def refresh(*_):
        if not app.JOB["running"]:
            threading.Thread(target=app.run_sources, kwargs={"mode": "full"}, daemon=True).start()

    tray = pystray.Icon("Vizo", Image.open(HERE / "vizo.png"), TITLE, menu=pystray.Menu(
        pystray.MenuItem("Deschide", lambda *_: show(), default=True),
        pystray.MenuItem("Caută acum", refresh),
        pystray.MenuItem("Verificare Imobiliare.ro", lambda *_: verify_imobiliare()),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Închide de tot", quit_all)))

    def tip(title, msg):
        try:
            tray.notify(msg, title)
        except Exception:
            pass

    app.NOTIFY[:] = [tip]

    # Imobiliare.ro blocheaza programele, dar nu un browser adevarat: o fereastra WebView2 ascunsa citeste anunturile.
    class ImoApi:
        def __init__(self):
            self.result, self.ev, self.items = None, threading.Event(), []

        def progress(self, i, n, info=""):
            if i <= -1000:   # mersul prin paginile de rezultate
                app.log(f"imobiliare: pagina {-i - 1000}/{n}")
            elif i < 0:   # diagnostic de pe prima pagina: cod HTTP, cate anunturi, titlul paginii
                app.log(f"imobiliare: prima pagina HTTP {-i}, {n} anunturi, {info[:120]}")
            else:
                app.log(f"imobiliare: detalii {i}/{n}")

        def chunk(self, payload):
            """Anunturile vin pe bucati (23.11.2026): un singur text cu mii de anunturi nu mai trecea sigur prin punte."""
            import json as _json
            try:
                self.items.extend(_json.loads(payload))
            except Exception:
                app.log("imobiliare: o bucata nu s-a putut citi")

        def done(self, payload):
            self.result = payload
            self.ev.set()

    imo_api = ImoApi()
    imo = webview.create_window("Vizo · Imobiliare (fundal)", "about:blank", hidden=True, js_api=imo_api, width=900, height=700)

    def imo_open(url, timeout=60):
        """Deschide url in fereastra ascunsa si asteapta `loaded`. WebView2 nu navigheaza cand adresa ceruta e chiar
        cea deschisa deja (imobiliare.js citeste cu fetch, deci fereastra ramane pe aceeasi adresa de la o cautare la
        alta), asa ca `loaded` nu mai venea niciodata. Trecem intai printr-o pagina goala (load_html navigheaza
        mereu), ca adresa ceruta sa fie de fiecare data o navigare noua. Nu get_current_url(): asteapta `loaded`."""
        imo.load_html("<html></html>")
        imo.events.loaded.wait(15)
        imo.load_url(url)   # load_url goleste events.loaded inainte sa navigheze
        return imo.events.loaded.wait(timeout)

    imo_lock = threading.Lock()   # o singura fereastra ascunsa: o singura citire odata (judetul activ sau altul)

    def scrape_imobiliare(log=print, known=None, max_price=80000, budget_min=30, detail_max=120, path=None, min_price=25000, **_):
        with imo_lock:
            return _scrape_imobiliare(log, known, max_price, budget_min, detail_max, path, min_price)

    def _scrape_imobiliare(log, known, max_price, budget_min, detail_max, path, min_price=25000):
        """-> lista de anunturi cu .complete (False = nu marca nimic disparut) si .summary (ce a spus cititorul)."""
        import json as _json
        imo_api.result = None
        imo_api.items = []
        imo_api.ev.clear()
        out = app.SourceList()
        out.complete = False
        # judetul activ, sau alt judet cand colectarea de fundal il cere (path dat de app.imobiliare_judet)
        path = path or app.model.orase.DEFAULT.get("imobiliare") or "judetul-brasov/brasov"
        if not imo_open(f"https://www.imobiliare.ro/vanzare-apartamente/{path}?price={int(min_price)}-{int(max_price)}"):
            log("imobiliare: pagina nu s-a incarcat")
            return out
        time.sleep(6)   # lasa protectia site-ului sa termine
        cfg = {"path": path, "min": int(min_price), "max": int(max_price), "known": sorted(known or []), "budget_min": budget_min, "detail_max": detail_max}
        imo.evaluate_js("window.__CASA_CFG = " + _json.dumps(cfg) + ";\n" +
                        (HERE / "imobiliare.js").read_text(encoding="utf-8") + "\n;void 0")   # nu astepta promisiunea
        if not imo_api.ev.wait((budget_min + 40) * 60):
            log(f"imobiliare: nu a terminat in {budget_min + 40} min; pastrez cele {len(imo_api.items)} primite")
            out.extend(imo_api.items)
            return out
        if imo_api.result == "BLOCKED":
            log("imobiliare: site-ul cere verificare (anti-roboti). Deschide din tray: Verificare Imobiliare.ro")
            tip("Imobiliare.ro cere o verificare",
                "Click dreapta pe iconita din tray > Verificare Imobiliare.ro. O faci o data, apoi merge singur.")
            return out
        try:
            summ = _json.loads(imo_api.result or "{}")
        except Exception:
            summ = {}
        if not isinstance(summ, dict):
            summ = {}
        out.extend(imo_api.items)
        out.summary = summ
        out.complete = bool(summ.get("complete")) and len(out) > 0
        if summ.get("error"):
            log("imobiliare: " + str(summ["error"]))
        else:
            log(f"imobiliare: site-ul are {summ.get('total')}, citite {summ.get('got')} din {summ.get('pages')} pagini; "
                f"{summ.get('withDetail')} noi cu detalii, {summ.get('noDetail')} noi fara detalii inca"
                + (f"; pagini lipsa: {summ.get('failed')}" if summ.get("failed") else "")
                + ("; site-ul a oprit paginile de anunt, continui la rularea urmatoare" if summ.get("detailBlocked") else "")
                + (f"; {summ.get('otherErr')} pagini de anunt cu eroare" if summ.get("otherErr") else ""))
        return out

    def verify_imobiliare(*_):
        """Fereastra devine vizibila: utilizatorul trece verificarea site-ului ca pe un site normal, apoi o inchide."""
        threading.Thread(target=imo_open, daemon=True,   # pagina proaspata, nu cea ramasa de la ultima cautare
                         args=("https://www.imobiliare.ro/vanzare-apartamente/judetul-brasov/brasov?price=25000-80000",)).start()
        imo.set_title("Imobiliare.ro: treci verificarea, apoi închide fereastra")
        imo.show()

    def imo_closing():
        if state["quit"]:
            return True
        imo.hide()
        app.imo_verified()   # verificarea s-a facut: bara din aplicatie dispare (revine doar daca site-ul blocheaza iar)
        return False

    imo.events.closing += imo_closing
    app.VERIFY[:] = [verify_imobiliare]

    app.BROWSER["imobiliare"] = scrape_imobiliare
    threading.Thread(target=tray.run, daemon=True).start()
    storage = app.model.orase.data_dir("brasov") / "webview"   # una pentru toate judetele: verificarea Imobiliare ramane
    storage.mkdir(parents=True, exist_ok=True)
    webview.start(private_mode=False, storage_path=str(storage))
    # 24.11.2026: fereastra s-a inchis (Inchide de tot, sau schimbarea judetului). Procesul trebuie sa se termine de tot:
    # altfel un fir ramas in viata tinea serverul pe port, copia noua (judetul ales) nu mai pornea, iar "Deschide"
    # ajungea la un proces fara fereastra -> "aplicatia se inchide / nu se deschide". Asteptam o salvare in curs, apoi iesim.
    import os
    got = app.model.LOCK.acquire(timeout=30)
    try:
        os._exit(0)
    finally:
        if got:
            app.model.LOCK.release()


if __name__ == "__main__":
    try:
        main()
    except BaseException as e:   # pythonw nu are consola: fara asta o pornire esuata nu lasa niciun semn
        if not isinstance(e, SystemExit):
            import traceback
            try:
                with open(app.model.orase.BASE_DATA / "desktop_erori.log", "a", encoding="utf-8") as f:
                    f.write(time.strftime("\n=== %Y-%m-%d %H:%M:%S ") + " ".join(sys.argv[1:]) + "\n" + traceback.format_exc())
            except Exception:
                pass
        raise
