// Cititorul pentru Imobiliare.ro. Ruleaza IN pagina imobiliare.ro (fereastra ascunsa a aplicatiei).
// Parcurge TOATE paginile de rezultate, apoi pagina fiecarui anunt nou, si trimite totul aplicatiei pe bucati:
// window.pywebview.api.chunk(json) de mai multe ori, apoi api.done(json cu rezumatul). Progres: api.progress(n, total).
//
// 2026-11-23: site-ul raspunde 404 la `?page=1`, deci prima pagina se cere fara `page`
// (din 18.11 cititorul nu mai aducea nimic); limita de 40 de pagini a disparut (Brasov are peste 60); o pagina care nu
// se incarca e reincercata; anunturile noi pentru care nu mai ajunge timpul pleaca totusi, fara detalii (`nodetail`),
// iar detaliile le ia rularea urmatoare. Nimic nu se pierde in tacere: rezumatul spune cate pagini au lipsit.
(async () => {
  /*H<*/
  const H = {
    // prima pagina NU are voie sa aiba parametrul page (site-ul da 404)
    pageUrl: (path, p, min, max) => `/vanzare-apartamente/${path}?` + (p > 1 ? `page=${p}&` : "") + `price=${min}-${max}`,
    // "Apartamente de vânzare în Brașov - 1.848 anunțuri" -> 1848
    totalFrom: title => { const m = (title || "").match(/([\d.]+)\s+anun/i); return m ? +m[1].replace(/\./g, "") : 0; },
    // cate pagini trebuie citite: cea mai mare legatura din pagina sau totalul impartit la cate incap pe pagina
    pagesFor: (total, perPage, maxLink) => Math.max(1, maxLink || 0, perPage > 0 ? Math.ceil(total / Math.min(perPage, 30)) : 0),
    // "6" zile pe piata -> data publicarii
    created: (days, now) => { const n = parseInt(days, 10); if (!(n >= 0) || n > 5000) return null;
      return new Date((now || new Date()).getTime() - n * 864e5).toISOString().slice(0, 10); },
    // cartierele din centru (numele de pe imobiliare.ro), pentru ordinea in care se iau detaliile
    central: ar => /centrul|central|ultracentral|schei|blumana|prund|brasovul vechi/i.test(ar || ""),
    // "Etaj 6" / "Etaj 10 / 10" / "Parter / 4" / "Demisol" de pe cartonasul din lista -> [etaj, cate etaje]
    floorFrom: s => { s = s || ""; const t = (s.match(/\/\s*(\d+)/) || [])[1]; const tot = t ? +t : null;
      if (/parter/i.test(s)) return [0, tot];
      if (/demisol|subsol/i.test(s)) return [-1, tot];
      const m = s.match(/(\d+)/); return m ? [+m[1], tot] : [null, null]; },
    // rularea e completa (anunturile nevazute pot fi numarate ca lipsa) doar daca nicio pagina nu a picat
    // si am strans aproape tot ce spune site-ul ca are
    complete: (total, got, failed) => failed.length === 0 && (!total || got >= 0.93 * total),
  };
  /*>H*/
  const CFG = window.__CASA_CFG || { path: "judetul-brasov/brasov", min: 25000, max: 150000 };
  const api = (window.pywebview && window.pywebview.api) || null;
  const known = new Set((CFG.known || []).map(String));
  const BUDGET = (CFG.budget_min || 30) * 60000, T0 = Date.now();
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const dec = s => s.replace(/&quot;/g, '"').replace(/&amp;/g, "&");
  const txt = (d, sel) => { const e = d.querySelector(sel); return e ? e.textContent.replace(/\s+/g, " ").trim() : null; };
  const say = (...a) => { if (api) { try { api.progress(...a); } catch (e) {} } };
  const SEL = "article[data-listing-id]";

  async function page(p) {   // -> {status, doc, n}; pana la 3 incercari
    let last = { status: 0, doc: null, n: 0 };
    for (let k = 0; k < 3; k++) {
      try {
        const resp = await fetch(H.pageUrl(CFG.path, p, CFG.min, CFG.max), { credentials: "include" });
        const doc = new DOMParser().parseFromString(await resp.text(), "text/html");
        last = { status: resp.status, doc, n: doc.querySelectorAll(SEL).length };
        if (last.n || resp.status === 403) return last;
      } catch (e) { last = { status: -1, doc: null, n: 0 }; }
      await sleep(1500 * (k + 1));
    }
    return last;
  }

  const imo = {}, failed = [];
  let pages = 1, total = 0, emptyRun = 0;
  for (let p = 1; p <= pages && p <= 400; p++) {
    const r = await page(p);
    if (p === 1) {
      say(-(r.status || 599), r.n, ((r.doc && r.doc.title) || document.title || "") + " | " + location.href);
      if (r.status === 403 && !r.n) { if (api) api.done("BLOCKED"); return; }   // site-ul cere verificare (o face utilizatorul)
      if (!r.n) { if (api) api.done(JSON.stringify({ error: "prima pagina fara anunturi, HTTP " + r.status })); return; }
      total = H.totalFrom(r.doc.title);
    }
    if (!r.n) {
      failed.push(p);
      if (++emptyRun >= 3) break;   // trei pagini la rand fara nimic: site-ul ne-a oprit, nu mai insistam
      continue;
    }
    emptyRun = 0;
    const nums = [...r.doc.querySelectorAll('a[href*="page="]')].map(a => +((a.getAttribute("href") || "").match(/page=(\d+)/) || [0, 0])[1]);
    pages = Math.max(pages, H.pagesFor(total, p === 1 ? r.n : 0, Math.max(0, ...nums)));
    for (const a of r.doc.querySelectorAll(SEL)) {
      const d = a.dataset, l = a.querySelector('a[href*="/oferta/"]');
      if (d.status && d.status !== "sale") continue;
      imo[d.listingId] = { id: d.listingId, u: l ? l.getAttribute("href") : "", n: d.name, p: +d.itemPrice, s: d.surface, ar: d.area,
        v: d.village, ct: d.city, y: d.year, st: d.sellertype, ag: d.affiliation, c2: d.category2, c3: d.category3, c4: d.category4,
        cr: H.created(d.daysMarket),
        // cartonasul din lista are deja pozele, etajul, camerele si inceputul descrierii: anuntul e folositor si
        // inainte sa-i putem citi pagina (23.11.2026)
        ph: [...new Set([...a.querySelectorAll("img,source")].map(i => i.getAttribute("src") || i.getAttribute("data-src") || "")
          .filter(u => /^https:\/\/i\.roamcdn\.net\/prop\/imo\/gallery-main-900w/.test(u)))].slice(0, 12),
        fl: txt(a, "[data-cy=card-floor_number]"), rm: txt(a, "[data-cy=card-bedroom_count]"),
        ds: (txt(a, "p") || "").slice(0, 600) };
    }
    if (p % 5 === 0) say(-1000 - p, pages, "");
    await sleep(700);
  }
  // paginile de dincolo de capat (numarate in plus din total) nu sunt o lipsa
  const got = Object.keys(imo).length;
  const realFailed = failed.filter(p => !(total && got >= 0.97 * total));
  const complete = H.complete(total, got, realFailed);

  const city = o => (o.v && o.v !== "not applicable") ? o.v : (o.ct && o.ct !== "not applicable" ? o.ct : "Brasov");
  const rooms0 = o => { const c = (o.rm || "").match(/(\d+)\s*camer/); if (c) return +c[1]; if (/garsonier/i.test(o.rm || "")) return 1;
    const m = (o.c3 || "").match(/(\d+)\s*bedroom/); return /studio|single/.test((o.c2 || "") + (o.c3 || "")) ? 1 : (m ? +m[1] : null); };
  const light = o => ({ source: "imobiliare", sid: o.id, url: "https://www.imobiliare.ro" + o.u, title: o.n, price: o.p,
    area: parseFloat(o.s) || null, rooms: rooms0(o), year: +o.y > 1800 ? +o.y : null, district: o.ar, raw_city: city(o),
    seller: o.st === "individual" ? "proprietar" : "agentie", seller_name: o.ag, created: o.cr,
    market: o.c4 === "new" ? "primary" : null, photos: o.ph || [], floor: H.floorFrom(o.fl)[0], floors_total: H.floorFrom(o.fl)[1],
    desc: o.ds || null });

  async function detail(o) {
    const resp = await fetch(o.u, { credentials: "include" });
    if (resp.status === 403) throw new Error("403");
    const t = await resp.text();
    const d = new DOMParser().parseFromString(t, "text/html"), T = dec(t);
    const m = T.match(/"center":\[(4[3-8]\.\d+),(2[0-9]\.\d+)\]/);
    const fl = txt(d, "[data-cy=summary-floor_number]") || "";
    let floor = null, tot = null; const fm = fl.match(/(\d+)\s*\/\s*(\d+)/);
    if (/parter/i.test(fl)) { floor = 0; const q = fl.match(/\/\s*(\d+)/); if (q) tot = +q[1]; }
    else if (/demisol|subsol/i.test(fl)) floor = -1;
    else if (fm) { floor = +fm[1]; tot = +fm[2]; }
    const yr = (txt(d, "[data-cy=summary-year_built]") || "").match(/(1[89]\d\d|20\d\d)/);
    // toate pozele din pagina (si cele din datele galeriei, nu doar cele deja incarcate)
    const ph = [...new Set([...(T.match(/https:\/\/i\.roamcdn\.net\/prop\/imo\/gallery-main-900w[^"'\s\\)]+/g) || []),
      ...[...d.querySelectorAll("img")].map(x => x.src || x.getAttribute("data-src") || "").filter(u => /gallery-main-900w/.test(u))])].slice(0, 20);
    const rooms = (txt(d, "[data-cy=summary-bedroom_count]") || "").match(/\d/);
    const desc = (txt(d, "[data-cy=listing-description-section]") || "").replace(/^Descriere apartament/, "");
    const spec = txt(d, "[data-cy=listing-specifications-panel]") || "", am = txt(d, "[data-cy=listing-amenities-excerpt-component]") || "";
    const base = light(o);
    return Object.assign(base, { title: txt(d, "[data-cy=listing-heading]") || o.n, rooms: rooms ? +rooms[0] : base.rooms,
      floor: floor != null ? floor : base.floor, floors_total: tot != null ? tot : base.floors_total, year: yr ? +yr[1] : base.year, address: txt(d, "[data-cy=listing-address]"),
      lat: m ? +m[1] : null, lon: m ? +m[2] : null, desc: (desc + "\nSpecificatii: " + spec + " " + am).slice(0, 6000),
      phone: null, photos: ph.length ? ph : base.photos, heating: null,
      partition: (txt(d, "[data-cy=key-feature-compartmentalization_type]") || "").toLowerCase() || null });
  }

  const items = Object.values(imo).filter(o => o.u && o.p >= CFG.min && o.p <= CFG.max);
  // Paginile de anunt se cer RAR (una odata, cu pauza) si cel mult DETAIL_MAX pe rulare: la prima incercare cu doua
  // deodata site-ul a blocat dupa ~30 de pagini (23.11.2026). Restul pleaca fara detalii si le iau rularile urmatoare.
  // Ordinea: centrul intai (ce cauta utilizatorul), apoi cele mai noi.
  const DETAIL_MAX = CFG.detail_max || 120;
  const central = o => H.central(o.ar) ? 0 : 1;
  const todo = items.filter(o => !known.has(String(o.id))).sort((a, b) => central(a) - central(b) || (b.cr || "").localeCompare(a.cr || ""));
  let buf = [], sent = 0, withDetail = 0, noDetail = 0, blocked = 0, otherErr = 0, i = 0;
  const flush = force => { if (buf.length && (force || buf.length >= 60)) { if (api) { try { api.chunk(JSON.stringify(buf)); } catch (e) {} } sent += buf.length; buf = []; } };
  for (const o of items) if (known.has(String(o.id))) buf.push(light(o));   // cunoscute: pretul de pe pagina de rezultate
  flush(true);
  async function worker() {
    while (todo.length) {
      const o = todo.shift();
      i++;
      let rec = null;
      if (blocked < 2 && withDetail < DETAIL_MAX && Date.now() - T0 < BUDGET) {
        try { rec = await detail(o); withDetail++; blocked = 0; } catch (e) { if (String(e.message) === "403") blocked++; else otherErr++; }
        await sleep(1100 + Math.random() * 900);
      }
      if (!rec) { rec = light(o); rec.nodetail = true; noDetail++; }
      buf.push(rec);
      flush(false);
      if (i % 10 === 0) say(i, i + todo.length);
    }
  }
  await worker();
  flush(true);
  const summary = { total, got, pages, failed: realFailed, complete, sent, withDetail, noDetail, detailBlocked: blocked >= 2, otherErr, known: items.length - withDetail - noDetail };
  window.__casa_out = summary;
  if (api) api.done(JSON.stringify(summary));
})();
