/* 28.11.2026: listele derulante ale aplicatiei (cererea: "arata foarte basic, fa-le mai frumoase, pe toate taburile").
   Fiecare <select> primeste in locul lui un buton si un meniu desenat de noi: numele si numarul aliniate ("Iasi  3.922"),
   "incă nu" estompat si mutat la final, cautare in listele lungi, tastatura (sageti, Enter, Esc, scris direct).
   <select>-ul original ramane in pagina (ascuns), cu valoarea si evenimentele lui: codul paginii nu se schimba. */
(function () {
  "use strict";
  if (window.VizoSelect) return;
  const css = `
.dd-native{position:absolute!important;opacity:0!important;pointer-events:none!important;width:1px!important;height:1px!important;overflow:hidden!important}
.dd-btn{display:inline-flex;align-items:center;justify-content:space-between;gap:10px;min-width:0;max-width:100%;height:40px;padding:0 12px 0 14px;
  border:1px solid rgb(var(--line));border-radius:12px;background:rgb(var(--panel));color:rgb(var(--ink));font:550 13.5px/1 var(--sans);
  text-align:left;cursor:pointer;transition:border-color .12s,box-shadow .12s}
.dd-btn:hover{border-color:rgb(var(--line2))}
.dd-btn:focus-visible{outline:none;border-color:rgb(var(--accent));box-shadow:0 0 0 3px rgb(var(--accent)/.15)}
.dd-btn[aria-expanded=true]{border-color:rgb(var(--accent));box-shadow:0 0 0 3px rgb(var(--accent)/.15)}
.dd-btn .dd-t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.dd-btn .dd-m{color:rgb(var(--mut));font-weight:500;margin-left:6px}
.dd-btn .dd-ch{flex:none;width:14px;height:14px;fill:none;stroke:rgb(var(--mut));stroke-width:2;stroke-linecap:round;stroke-linejoin:round;transition:transform .15s}
.dd-btn[aria-expanded=true] .dd-ch{transform:rotate(180deg)}
.dd-btn[hidden]{display:none}
.dd-pop{position:fixed;z-index:5000;display:flex;flex-direction:column;min-width:220px;max-height:min(62vh,540px);padding:6px;
  background:rgb(var(--panel));border:1px solid rgb(var(--line));border-radius:14px;box-shadow:var(--shadow-pop);animation:ddin .12s ease-out}
@keyframes ddin{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
.dd-q{flex:none;height:38px;margin:2px 2px 6px;padding:0 12px;border:1px solid rgb(var(--line));border-radius:10px;background:rgb(var(--panel2));
  color:rgb(var(--ink));font:500 13.5px var(--sans)}
.dd-q:focus{outline:none;border-color:rgb(var(--accent))}
.dd-list{overflow:auto;overscroll-behavior:contain}
.dd-o{display:grid;grid-template-columns:16px 1fr auto;gap:10px;align-items:center;padding:9px 10px;border-radius:9px;cursor:pointer;
  font:500 13.5px/1.25 var(--sans);color:rgb(var(--body))}
.dd-o:hover,.dd-o.act{background:rgb(var(--panel3));color:rgb(var(--ink))}
.dd-o.sel{color:rgb(var(--ink));font-weight:650}
.dd-o .ck{width:14px;height:14px;fill:none;stroke:rgb(var(--accent));stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}
.dd-o .m{color:rgb(var(--mut));font-size:12.5px;font-weight:500;font-variant-numeric:tabular-nums;white-space:nowrap}
.dd-o.dim{color:rgb(var(--mut))}
.dd-o.dis{opacity:.45;cursor:default}
.dd-h{padding:10px 10px 4px;font:600 12px var(--sans);color:rgb(var(--mut));border-top:1px solid rgb(var(--line));margin-top:4px}
.dd-h:first-child{border-top:0;margin-top:0}
.dd-none{padding:14px 10px;color:rgb(var(--mut));font-size:13px}
`;
  const st = document.createElement("style");
  st.textContent = css;
  document.head.appendChild(st);

  const CH = '<svg class="dd-ch" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
  const CK = '<svg class="ck" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
  const fold = s => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  // "Iasi (3.922)" -> ["Iasi", "3.922"];  "Ilfov · Buftea (inca nu)" -> ["Ilfov · Buftea", "inca nu"]
  const split = t => { const m = /^(.*?)\s*\(([^()]*)\)\s*$/.exec(t || ""); return m && m[1] ? [m[1], m[2]] : [t || "", ""]; };
  const isNot = meta => /^(inca nu|încă nu|0)$/i.test(meta.trim());
  const ALL = new Set();
  let open = null;

  function label(sel, btn) {
    const o = sel.options[sel.selectedIndex];
    const [t, m] = split(o ? o.textContent : "");
    btn.innerHTML = `<span class="dd-t">${esc(t)}${m ? `<span class="dd-m">${esc(m)}</span>` : ""}</span>${CH}`;
    btn.title = sel.title || "";
    btn.hidden = sel.hidden;
    btn.disabled = sel.disabled;
    btn._v = sel.value + "|" + sel.options.length + "|" + sel.hidden;
  }

  function enhance(sel) {
    if (sel._dd || sel.multiple || sel.dataset.native != null || sel.closest(".dd-pop")) return;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "dd-btn " + sel.className;
    btn.setAttribute("aria-haspopup", "listbox");
    btn.setAttribute("aria-expanded", "false");
    if (sel.getAttribute("aria-label")) btn.setAttribute("aria-label", sel.getAttribute("aria-label"));
    sel.after(btn);
    sel.classList.add("dd-native");
    sel.tabIndex = -1;
    sel._dd = btn;
    btn._sel = sel;
    label(sel, btn);
    btn.addEventListener("click", e => { e.stopPropagation(); open && open.btn === btn ? close() : show(btn); });
    btn.addEventListener("keydown", e => {
      if (["ArrowDown", "ArrowUp", "Enter", " "].includes(e.key)) { e.preventDefault(); show(btn); }
    });
    sel.addEventListener("change", () => label(sel, btn));
    new MutationObserver(() => label(sel, btn)).observe(sel, {childList: true, subtree: true, attributes: true, attributeFilter: ["hidden", "disabled", "class"]});
    ALL.add(sel);
  }

  function show(btn) {
    close();
    const sel = btn._sel, opts = [...sel.options], long = opts.length > 9;
    const pop = document.createElement("div");
    pop.className = "dd-pop";
    pop.setAttribute("role", "listbox");
    pop.innerHTML = (long ? `<input class="dd-q" type="search" placeholder="Caută…" aria-label="Caută în listă" autocomplete="off">` : "") + `<div class="dd-list"></div>`;
    document.body.appendChild(pop);
    const list = pop.querySelector(".dd-list"), q = pop.querySelector(".dd-q");
    let act = -1, shown = [];
    const paint = () => {
      const f = fold(q ? q.value.trim() : "");
      const items = opts.map((o, i) => ({o, i, t: split(o.textContent)})).filter(x => !f || fold(x.o.textContent).includes(f));
      // ce inca nu are date ("încă nu", 0) trece dupa celelalte, sub un titlu
      const ready = items.filter(x => !(x.t[1] && isNot(x.t[1]) && x.o.value !== "")), later = items.filter(x => !ready.includes(x));
      shown = ready.concat(later);
      const row = x => `<div class="dd-o${x.o.selected ? " sel" : ""}${later.includes(x) ? " dim" : ""}${x.o.disabled ? " dis" : ""}" role="option" data-i="${x.i}" aria-selected="${x.o.selected}">
        ${x.o.selected ? CK : "<span></span>"}<span>${esc(x.t[0])}</span><span class="m">${esc(x.t[1])}</span></div>`;
      list.innerHTML = shown.length ? ready.map(row).join("") + (later.length && ready.length ? `<div class="dd-h">${later.length === 1 ? "Încă fără date" : `Încă fără date (${later.length})`}</div>` : "") + later.map(row).join("")
        : `<div class="dd-none">Nimic pentru „${esc(q.value)}”.</div>`;
      act = shown.findIndex(x => x.o.selected);
      mark();
    };
    const mark = () => {
      list.querySelectorAll(".dd-o").forEach((el, k) => el.classList.toggle("act", k === act));
      const a = list.querySelectorAll(".dd-o")[act];
      if (a) a.scrollIntoView({block: "nearest"});
    };
    const pick = i => {
      const o = opts[i];
      if (!o || o.disabled) return;
      sel.value = o.value;
      sel.dispatchEvent(new Event("input", {bubbles: true}));
      sel.dispatchEvent(new Event("change", {bubbles: true}));
      label(sel, btn);
      close();
      btn.focus();
    };
    paint();
    list.addEventListener("mousedown", e => e.preventDefault());
    list.addEventListener("click", e => { const r = e.target.closest(".dd-o"); if (r) pick(+r.dataset.i); });
    if (q) q.addEventListener("input", paint);
    pop.addEventListener("keydown", e => {
      if (e.key === "ArrowDown") { e.preventDefault(); act = Math.min(shown.length - 1, act + 1); mark(); }
      else if (e.key === "ArrowUp") { e.preventDefault(); act = Math.max(0, act - 1); mark(); }
      else if (e.key === "Enter") { e.preventDefault(); if (shown[act]) pick(shown[act].i); }
      else if (e.key === "Escape") { e.preventDefault(); close(); btn.focus(); }
      else if (e.key === "Tab") close();
    });
    place(btn, pop);
    btn.setAttribute("aria-expanded", "true");
    open = {btn, pop};
    if (q) q.focus();
    else { pop.tabIndex = -1; pop.focus(); }
  }

  function place(btn, pop) {
    const r = btn.getBoundingClientRect(), vw = innerWidth, vh = innerHeight;
    pop.style.minWidth = Math.max(220, r.width) + "px";
    const w = pop.offsetWidth, h = pop.offsetHeight;
    let left = Math.min(r.left, vw - w - 8), top = r.bottom + 6;
    if (top + h > vh - 8 && r.top - h - 6 > 8) top = r.top - h - 6;      // nu incape dedesubt: se deschide deasupra
    pop.style.left = Math.max(8, left) + "px";
    pop.style.top = Math.max(8, top) + "px";
  }

  function close() {
    if (!open) return;
    open.btn.setAttribute("aria-expanded", "false");
    open.pop.remove();
    open = null;
  }

  document.addEventListener("click", e => { if (open && !open.pop.contains(e.target)) close(); });
  addEventListener("resize", close);
  document.addEventListener("scroll", e => { if (open && !open.pop.contains(e.target)) close(); }, true);
  // valori puse din cod (sel.value = ...) nu dau eveniment: eticheta se potriveste la 400 ms
  setInterval(() => { for (const s of ALL) { if (!s.isConnected) { ALL.delete(s); continue; } const b = s._dd;
    if (b && b._v !== s.value + "|" + s.options.length + "|" + s.hidden) label(s, b); } }, 400);
  const scan = root => (root.querySelectorAll ? root.querySelectorAll("select") : []).forEach(enhance);
  new MutationObserver(ms => { for (const m of ms) m.addedNodes.forEach(n => { if (n.nodeType !== 1) return;
    if (n.tagName === "SELECT") enhance(n); else scan(n); }); }).observe(document.documentElement, {childList: true, subtree: true});
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => scan(document));
  else scan(document);
  window.VizoSelect = {enhance, close};
})();
