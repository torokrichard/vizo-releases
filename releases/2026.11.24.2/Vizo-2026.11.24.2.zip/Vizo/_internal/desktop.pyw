"""Casa in Brasov ca aplicatie Windows: fereastra proprie (WebView2), iconita in bara de activitati si in tray.

Inchiderea ferestrei NU opreste aplicatia: ramane langa ceas si cauta singura la fiecare 3 ore.
Iesi din meniul iconitei din tray ("Inchide de tot"). Cu --tray porneste ascunsa (la pornirea Windows).
"""
import ctypes
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

HERE = Path(__file__).parent
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Vizo.App")
sys.path.insert(0, str(HERE))

# --colecteaza <judet> <full|fast>: procesul de fundal care cauta un alt judet (pornit de app.judete_loop), fara fereastra.
# Judetul trebuie stiut INAINTE de import app (orase.py alege dosarul de date la import).
_COL = sys.argv[sys.argv.index("--colecteaza") + 1:] if "--colecteaza" in sys.argv else None
if _COL:
    import os as _os
    _os.environ["VIZO_CITY"] = _COL[0]

import app  # noqa: E402

if _COL:
    try:
        app.headless_collect(_COL[1] if len(_COL) > 1 else "full")
    finally:
        sys.exit(0)
import webview  # noqa: E402

TITLE = "Vizo"


def already_running():
    try:
        urllib.request.urlopen(app.URL + "api/status", timeout=2)
        return True
    except Exception:
        return False


def set_icon():
    u = ctypes.windll.user32
    ico = str(HERE / "vizo.ico")
    for _ in range(60):
        h = u.FindWindowW(None, TITLE)
        if h:
            u.SendMessageW(h, 0x80, 1, u.LoadImageW(None, ico, 1, 256, 256, 0x10))
            u.SendMessageW(h, 0x80, 0, u.LoadImageW(None, ico, 1, 32, 32, 0x10))
            return
        time.sleep(0.1)


BAR = {"bg": (244, 243, 239), "fg": (17, 17, 17), "dark": False}   # ultima culoare ceruta de pagina deschisa


def set_titlebar(bg=None, fg=None, dark=None):
    """Bara de titlu Windows in culorile paginii (Windows 11: fundal, text, chenar; tema inchisa pentru butoane),
    ca sa nu mai fie o fasie gri deasupra aplicatiei. Pe Windows 10 atributele de culoare lipsesc: ramane bara standard."""
    if bg is not None:
        BAR.update(bg=bg, fg=fg, dark=dark)
    h = ctypes.windll.user32.FindWindowW(None, TITLE)
    if not h:
        return
    ref = lambda c: c[0] | (c[1] << 8) | (c[2] << 16)   # COLORREF = 0x00BBGGRR
    for attr, val in ((20, 1 if BAR["dark"] else 0), (35, ref(BAR["bg"])), (36, ref(BAR["fg"])), (34, ref(BAR["bg"]))):
        v = ctypes.c_int(val)
        try:
            ctypes.windll.dwmapi.DwmSetWindowAttribute(h, attr, ctypes.byref(v), ctypes.sizeof(v))
        except Exception:
            pass


def relaunch():
    """Schimbarea judetului (23.11.2026): datele si modelul sunt pe judet, asa ca aplicatia porneste din nou pe el.
    Copia noua asteapta (--dupa-restart) pana se elibereaza portul, apoi aceasta se inchide."""
    import subprocess
    cmd = [sys.executable] if getattr(sys, "frozen", False) else [sys.executable, str(Path(__file__).resolve())]
    subprocess.Popen(cmd + ["--dupa-restart"], cwd=str(HERE), close_fds=True)


def main():
    if "--dupa-restart" in sys.argv:
        for _ in range(60):
            if not already_running():
                break
            time.sleep(0.5)
    if already_running():
        # o copie ruleaza deja (in tray): doar deschidem fereastra ei
        try:
            urllib.request.urlopen(urllib.request.Request(app.URL + "api/show", data=b"{}", method="POST"), timeout=2)
        except Exception:
            webbrowser.open(app.URL)
        return
    app.start()
    hidden = "--tray" in sys.argv
    w = webview.create_window(TITLE, app.URL, width=1440, height=920, min_size=(420, 600),
                              background_color="#F4F3EF", text_select=True, zoomable=True, hidden=hidden)
    state = {"quit": False}

    def show():
        w.show(); w.restore()

    def on_closing():
        if state["quit"]:
            return True
        w.hide()
        tip("Vizo rulează în continuare", "Caută singur la fiecare 20 de minute. Îl găsești lângă ceas.")
        return False

    w.events.closing += on_closing
    w.events.shown += lambda: threading.Thread(target=set_icon, daemon=True).start()
    w.events.shown += lambda: set_titlebar()
    app.SHOW[:] = [show]
    app.WINBAR[:] = [set_titlebar]

    import pystray
    from PIL import Image

    def quit_all(*_):
        state["quit"] = True
        try:
            tray.stop()
        except Exception:
            pass
        w.destroy()

    def restart(*_):
        relaunch()
        quit_all()

    app.RESTART[:] = [restart]

    def refresh(*_):
        if not app.JOB["running"]:
            threading.Thread(target=app.run_sources, kwargs={"mode": "full"}, daemon=True).start()

    tray = pystray.Icon("Vizo", Image.open(HERE / "vizo.png"), TITLE, menu=pystray.Menu(
        pystray.MenuItem("Deschide", lambda *_: show(), default=True),
        pystray.MenuItem("Caută acum", refresh),
        pystray.MenuItem("Verificare Imobiliare.ro", lambda *_: verify_imobiliare()),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Închide de tot", quit_all)))

    def tip(title, msg):
        try:
            tray.notify(msg, title)
        except Exception:
            pass

    app.NOTIFY[:] = [tip]

    # Imobiliare.ro blocheaza programele, dar nu un browser adevarat: o fereastra WebView2 ascunsa citeste anunturile.
    class ImoApi:
        def __init__(self):
            self.result, self.ev, self.items = None, threading.Event(), []

        def progress(self, i, n, info=""):
            if i <= -1000:   # mersul prin paginile de rezultate
                app.log(f"imobiliare: pagina {-i - 1000}/{n}")
            elif i < 0:   # diagnostic de pe prima pagina: cod HTTP, cate anunturi, titlul paginii
                app.log(f"imobiliare: prima pagina HTTP {-i}, {n} anunturi, {info[:120]}")
            else:
                app.log(f"imobiliare: detalii {i}/{n}")

        def chunk(self, payload):
            """Anunturile vin pe bucati (23.11.2026): un singur text cu mii de anunturi nu mai trecea sigur prin punte."""
            import json as _json
            try:
                self.items.extend(_json.loads(payload))
            except Exception:
                app.log("imobiliare: o bucata nu s-a putut citi")

        def done(self, payload):
            self.result = payload
            self.ev.set()

    imo_api = ImoApi()
    imo = webview.create_window("Vizo · Imobiliare (fundal)", "about:blank", hidden=True, js_api=imo_api, width=900, height=700)

    def imo_open(url, timeout=60):
        """Deschide url in fereastra ascunsa si asteapta `loaded`. WebView2 nu navigheaza cand adresa ceruta e chiar
        cea deschisa deja (imobiliare.js citeste cu fetch, deci fereastra ramane pe aceeasi adresa de la o cautare la
        alta), asa ca `loaded` nu mai venea niciodata. Trecem intai printr-o pagina goala (load_html navigheaza
        mereu), ca adresa ceruta sa fie de fiecare data o navigare noua. Nu get_current_url(): asteapta `loaded`."""
        imo.load_html("<html></html>")
        imo.events.loaded.wait(15)
        imo.load_url(url)   # load_url goleste events.loaded inainte sa navigheze
        return imo.events.loaded.wait(timeout)

    imo_lock = threading.Lock()   # o singura fereastra ascunsa: o singura citire odata (judetul activ sau altul)

    def scrape_imobiliare(log=print, known=None, max_price=80000, budget_min=30, detail_max=120, path=None, **_):
        with imo_lock:
            return _scrape_imobiliare(log, known, max_price, budget_min, detail_max, path)

    def _scrape_imobiliare(log, known, max_price, budget_min, detail_max, path):
        """-> lista de anunturi cu .complete (False = nu marca nimic disparut) si .summary (ce a spus cititorul)."""
        import json as _json
        imo_api.result = None
        imo_api.items = []
        imo_api.ev.clear()
        out = app.SourceList()
        out.complete = False
        # judetul activ, sau alt judet cand colectarea de fundal il cere (path dat de app.imobiliare_judet)
        path = path or app.model.orase.DEFAULT.get("imobiliare") or "judetul-brasov/brasov"
        if not imo_open(f"https://www.imobiliare.ro/vanzare-apartamente/{path}?price=25000-{int(max_price)}"):
            log("imobiliare: pagina nu s-a incarcat")
            return out
        time.sleep(6)   # lasa protectia site-ului sa termine
        cfg = {"path": path, "min": 25000, "max": int(max_price), "known": sorted(known or []), "budget_min": budget_min, "detail_max": detail_max}
        imo.evaluate_js("window.__CASA_CFG = " + _json.dumps(cfg) + ";\n" +
                        (HERE / "imobiliare.js").read_text(encoding="utf-8") + "\n;void 0")   # nu astepta promisiunea
        if not imo_api.ev.wait((budget_min + 40) * 60):
            log(f"imobiliare: nu a terminat in {budget_min + 40} min; pastrez cele {len(imo_api.items)} primite")
            out.extend(imo_api.items)
            return out
        if imo_api.result == "BLOCKED":
            log("imobiliare: site-ul cere verificare (anti-roboti). Deschide din tray: Verificare Imobiliare.ro")
            tip("Imobiliare.ro cere o verificare",
                "Click dreapta pe iconita din tray > Verificare Imobiliare.ro. O faci o data, apoi merge singur.")
            return out
        try:
            summ = _json.loads(imo_api.result or "{}")
        except Exception:
            summ = {}
        if not isinstance(summ, dict):
            summ = {}
        out.extend(imo_api.items)
        out.summary = summ
        out.complete = bool(summ.get("complete")) and len(out) > 0
        if summ.get("error"):
            log("imobiliare: " + str(summ["error"]))
        else:
            log(f"imobiliare: site-ul are {summ.get('total')}, citite {summ.get('got')} din {summ.get('pages')} pagini; "
                f"{summ.get('withDetail')} noi cu detalii, {summ.get('noDetail')} noi fara detalii inca"
                + (f"; pagini lipsa: {summ.get('failed')}" if summ.get("failed") else "")
                + ("; site-ul a oprit paginile de anunt, continui la rularea urmatoare" if summ.get("detailBlocked") else "")
                + (f"; {summ.get('otherErr')} pagini de anunt cu eroare" if summ.get("otherErr") else ""))
        return out

    def verify_imobiliare(*_):
        """Fereastra devine vizibila: TR trece verificarea site-ului ca pe un site normal, apoi o inchide."""
        threading.Thread(target=imo_open, daemon=True,   # pagina proaspata, nu cea ramasa de la ultima cautare
                         args=("https://www.imobiliare.ro/vanzare-apartamente/judetul-brasov/brasov?price=25000-80000",)).start()
        imo.set_title("Imobiliare.ro: treci verificarea, apoi închide fereastra")
        imo.show()

    def imo_closing():
        if state["quit"]:
            return True
        imo.hide()
        app.imo_verified()   # verificarea s-a facut: bara din aplicatie dispare (revine doar daca site-ul blocheaza iar)
        return False

    imo.events.closing += imo_closing
    app.VERIFY[:] = [verify_imobiliare]

    app.BROWSER["imobiliare"] = scrape_imobiliare
    threading.Thread(target=tray.run, daemon=True).start()
    storage = app.model.orase.data_dir("brasov") / "webview"   # una pentru toate judetele: verificarea Imobiliare ramane
    storage.mkdir(parents=True, exist_ok=True)
    webview.start(private_mode=False, storage_path=str(storage))


if __name__ == "__main__":
    main()
