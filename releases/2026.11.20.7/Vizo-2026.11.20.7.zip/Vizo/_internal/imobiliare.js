// Cititorul pentru Imobiliare.ro. Ruleaza IN pagina imobiliare.ro (fereastra ascunsa a aplicatiei).
// Parcurge toate paginile de rezultate, apoi pagina fiecarui anunt, si trimite totul aplicatiei prin
// window.pywebview.api.done(json). Progresul: window.pywebview.api.progress(n, total).
(async () => {
  const CFG = window.__CASA_CFG || { path: "judetul-brasov/brasov", min: 25000, max: 80000 };
  const api = (window.pywebview && window.pywebview.api) || null;
  const known = new Set((CFG.known || []).map(String));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const dec = s => s.replace(/&quot;/g, '"').replace(/&amp;/g, "&");
  const txt = (d, sel) => { const e = d.querySelector(sel); return e ? e.textContent.replace(/\s+/g, " ").trim() : null; };
  const imo = {};
  let pages = 1;
  for (let p = 1; p <= Math.min(pages, 40); p++) {
    const resp = await fetch(`/vanzare-apartamente/${CFG.path}?page=${p}&price=${CFG.min}-${CFG.max}`);
    const t = await resp.text();
    const doc = new DOMParser().parseFromString(t, "text/html");
    if (p === 1 && api) { try { api.progress(-resp.status, doc.querySelectorAll("article[data-listing-id]").length, (document.title || "") + " | " + location.href); } catch (e) {} }
    if (p === 1 && resp.status === 403) { if (api) api.done("BLOCKED"); return; }   // site-ul cere verificare (o face TR)
    if (p === 1) {
      const nums = [...doc.querySelectorAll('a[href*="page="]')].map(a => +(a.href.match(/page=(\d+)/) || [0, 0])[1]);
      pages = Math.max(1, ...nums);
    }
    for (const a of doc.querySelectorAll("article[data-listing-id]")) {
      const d = a.dataset, l = a.querySelector('a[href*="/oferta/"]');
      imo[d.listingId] = { id: d.listingId, u: l ? l.getAttribute("href") : "", n: d.name, p: +d.itemPrice, s: d.surface, ar: d.area,
        v: d.village, y: d.year, st: d.sellertype, ag: d.affiliation, c2: d.category2, c4: d.category4 };
    }
    await sleep(800);
  }
  const items = Object.values(imo), out = [];
  let i = 0;
  for (const o of items) {
    i++;
    try {
      if (o.p > CFG.max || o.p < CFG.min || !o.u) continue;
      if (known.has(String(o.id))) {   // anunt cunoscut: doar pretul de pe pagina de rezultate (verificare rapida)
        out.push({ source: "imobiliare", sid: o.id, url: "https://www.imobiliare.ro" + o.u, title: o.n, price: o.p,
          area: parseFloat(o.s) || null, district: o.ar, raw_city: (o.v && o.v !== "not applicable") ? o.v : "Brasov", photos: [] });
        continue;
      }
      const t = await (await fetch(o.u)).text();
      const d = new DOMParser().parseFromString(t, "text/html"), T = dec(t);
      const m = T.match(/"center":\[(4[3-8]\.\d+),(2[0-9]\.\d+)\]/);
      const fl = txt(d, "[data-cy=summary-floor_number]") || "";
      let floor = null, tot = null; const fm = fl.match(/(\d+)\s*\/\s*(\d+)/);
      if (/parter/i.test(fl)) { floor = 0; const q = fl.match(/\/\s*(\d+)/); if (q) tot = +q[1]; }
      else if (/demisol|subsol/i.test(fl)) floor = -1;
      else if (fm) { floor = +fm[1]; tot = +fm[2]; }
      const yr = (txt(d, "[data-cy=summary-year_built]") || "").match(/(1[89]\d\d|20\d\d)/);
      // toate pozele din pagina (si cele din datele galeriei, nu doar cele deja incarcate)
      const ph = [...new Set([...(T.match(/https:\/\/i\.roamcdn\.net\/prop\/imo\/gallery-main-900w[^"'\s\\)]+/g) || []),
        ...[...d.querySelectorAll("img")].map(x => x.src || x.getAttribute("data-src") || "").filter(u => /gallery-main-900w/.test(u))])].slice(0, 20);
      const rooms = (txt(d, "[data-cy=summary-bedroom_count]") || "").match(/\d/);
      const desc = (txt(d, "[data-cy=listing-description-section]") || "").replace(/^Descriere apartament/, "");
      const spec = txt(d, "[data-cy=listing-specifications-panel]") || "", am = txt(d, "[data-cy=listing-amenities-excerpt-component]") || "";
      out.push({ source: "imobiliare", sid: o.id, url: "https://www.imobiliare.ro" + o.u, title: txt(d, "[data-cy=listing-heading]") || o.n,
        price: o.p, area: parseFloat(o.s) || null, rooms: rooms ? +rooms[0] : (o.c2 && /single/.test(o.c2) ? 1 : null), floor, floors_total: tot,
        year: yr ? +yr[1] : (+o.y > 1800 ? +o.y : null), district: o.ar, address: txt(d, "[data-cy=listing-address]"),
        lat: m ? +m[1] : null, lon: m ? +m[2] : null, desc: (desc + "\nSpecificatii: " + spec + " " + am).slice(0, 6000),
        seller: o.st === "individual" ? "proprietar" : "agentie", seller_name: o.ag, phone: null, photos: ph, created: null,
        partition: (txt(d, "[data-cy=key-feature-compartmentalization_type]") || "").toLowerCase() || null, heating: null,
        raw_city: (o.v && o.v !== "not applicable") ? o.v : "Brasov", market: o.c4 === "new" ? "primary" : null });
    } catch (e) {}
    if (api && i % 10 === 0) { try { api.progress(i, items.length); } catch (e) {} }
    await sleep(700);
  }
  window.__casa_out = out;
  if (api) api.done(JSON.stringify(out));
})();
