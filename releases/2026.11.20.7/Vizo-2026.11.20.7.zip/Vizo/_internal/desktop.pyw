"""Casa in Brasov ca aplicatie Windows: fereastra proprie (WebView2), iconita in bara de activitati si in tray.

Inchiderea ferestrei NU opreste aplicatia: ramane langa ceas si cauta singura la fiecare 3 ore.
Iesi din meniul iconitei din tray ("Inchide de tot"). Cu --tray porneste ascunsa (la pornirea Windows).
"""
import ctypes
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

HERE = Path(__file__).parent
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Vizo.App")
sys.path.insert(0, str(HERE))

import app  # noqa: E402
import webview  # noqa: E402

TITLE = "Vizo"


def already_running():
    try:
        urllib.request.urlopen(app.URL + "api/status", timeout=2)
        return True
    except Exception:
        return False


def set_icon():
    u = ctypes.windll.user32
    ico = str(HERE / "vizo.ico")
    for _ in range(60):
        h = u.FindWindowW(None, TITLE)
        if h:
            u.SendMessageW(h, 0x80, 1, u.LoadImageW(None, ico, 1, 256, 256, 0x10))
            u.SendMessageW(h, 0x80, 0, u.LoadImageW(None, ico, 1, 32, 32, 0x10))
            return
        time.sleep(0.1)


BAR = {"bg": (244, 243, 239), "fg": (17, 17, 17), "dark": False}   # ultima culoare ceruta de pagina deschisa


def set_titlebar(bg=None, fg=None, dark=None):
    """Bara de titlu Windows in culorile paginii (Windows 11: fundal, text, chenar; tema inchisa pentru butoane),
    ca sa nu mai fie o fasie gri deasupra aplicatiei. Pe Windows 10 atributele de culoare lipsesc: ramane bara standard."""
    if bg is not None:
        BAR.update(bg=bg, fg=fg, dark=dark)
    h = ctypes.windll.user32.FindWindowW(None, TITLE)
    if not h:
        return
    ref = lambda c: c[0] | (c[1] << 8) | (c[2] << 16)   # COLORREF = 0x00BBGGRR
    for attr, val in ((20, 1 if BAR["dark"] else 0), (35, ref(BAR["bg"])), (36, ref(BAR["fg"])), (34, ref(BAR["bg"]))):
        v = ctypes.c_int(val)
        try:
            ctypes.windll.dwmapi.DwmSetWindowAttribute(h, attr, ctypes.byref(v), ctypes.sizeof(v))
        except Exception:
            pass


def main():
    if already_running():
        # o copie ruleaza deja (in tray): doar deschidem fereastra ei
        try:
            urllib.request.urlopen(urllib.request.Request(app.URL + "api/show", data=b"{}", method="POST"), timeout=2)
        except Exception:
            webbrowser.open(app.URL)
        return
    app.start()
    hidden = "--tray" in sys.argv
    w = webview.create_window(TITLE, app.URL, width=1440, height=920, min_size=(420, 600),
                              background_color="#F4F3EF", text_select=True, zoomable=True, hidden=hidden)
    state = {"quit": False}

    def show():
        w.show(); w.restore()

    def on_closing():
        if state["quit"]:
            return True
        w.hide()
        tip("Vizo rulează în continuare", "Caută singur la fiecare 20 de minute. Îl găsești lângă ceas.")
        return False

    w.events.closing += on_closing
    w.events.shown += lambda: threading.Thread(target=set_icon, daemon=True).start()
    w.events.shown += lambda: set_titlebar()
    app.SHOW[:] = [show]
    app.WINBAR[:] = [set_titlebar]

    import pystray
    from PIL import Image

    def quit_all(*_):
        state["quit"] = True
        try:
            tray.stop()
        except Exception:
            pass
        w.destroy()

    def refresh(*_):
        if not app.JOB["running"]:
            threading.Thread(target=app.run_sources, kwargs={"mode": "full"}, daemon=True).start()

    tray = pystray.Icon("Vizo", Image.open(HERE / "vizo.png"), TITLE, menu=pystray.Menu(
        pystray.MenuItem("Deschide", lambda *_: show(), default=True),
        pystray.MenuItem("Caută acum", refresh),
        pystray.MenuItem("Verificare Imobiliare.ro", lambda *_: verify_imobiliare()),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Închide de tot", quit_all)))

    def tip(title, msg):
        try:
            tray.notify(msg, title)
        except Exception:
            pass

    app.NOTIFY[:] = [tip]

    # Imobiliare.ro blocheaza programele, dar nu un browser adevarat: o fereastra WebView2 ascunsa citeste anunturile.
    class ImoApi:
        def __init__(self):
            self.result, self.ev = None, threading.Event()

        def progress(self, i, n, info=""):
            if i < 0:   # diagnostic de pe prima pagina: cod HTTP, cate anunturi, titlul paginii
                app.log(f"imobiliare: prima pagina HTTP {-i}, {n} anunturi, {info[:120]}")
            else:
                app.log(f"imobiliare: {i}/{n}")

        def done(self, payload):
            self.result = payload
            self.ev.set()

    imo_api = ImoApi()
    imo = webview.create_window("Vizo · Imobiliare (fundal)", "about:blank", hidden=True, js_api=imo_api, width=900, height=700)

    def imo_open(url, timeout=60):
        """Deschide url in fereastra ascunsa si asteapta `loaded`. WebView2 nu navigheaza cand adresa ceruta e chiar
        cea deschisa deja (imobiliare.js citeste cu fetch, deci fereastra ramane pe aceeasi adresa de la o cautare la
        alta), asa ca `loaded` nu mai venea niciodata. Trecem intai printr-o pagina goala (load_html navigheaza
        mereu), ca adresa ceruta sa fie de fiecare data o navigare noua. Nu get_current_url(): asteapta `loaded`."""
        imo.load_html("<html></html>")
        imo.events.loaded.wait(15)
        imo.load_url(url)   # load_url goleste events.loaded inainte sa navigheze
        return imo.events.loaded.wait(timeout)

    def scrape_imobiliare(log=print, known=None, max_price=80000, **_):
        import json as _json
        imo_api.result = None
        imo_api.ev.clear()
        if not imo_open(f"https://www.imobiliare.ro/vanzare-apartamente/judetul-brasov/brasov?price=25000-{int(max_price)}"):
            log("imobiliare: pagina nu s-a incarcat")
            return []
        time.sleep(6)   # lasa protectia site-ului sa termine
        cfg = {"path": "judetul-brasov/brasov", "min": 25000, "max": int(max_price), "known": sorted(known or [])}
        imo.evaluate_js("window.__CASA_CFG = " + _json.dumps(cfg) + ";\n" +
                        (HERE / "imobiliare.js").read_text(encoding="utf-8") + "\n;void 0")   # nu astepta promisiunea
        if not imo_api.ev.wait(45 * 60):
            log("imobiliare: nu a terminat in 45 min")
            return []
        if imo_api.result == "BLOCKED":
            log("imobiliare: site-ul cere verificare (anti-roboti). Deschide din tray: Verificare Imobiliare.ro")
            tip("Imobiliare.ro cere o verificare",
                "Click dreapta pe iconita din tray > Verificare Imobiliare.ro. O faci o data, apoi merge singur.")
            return []
        try:
            return _json.loads(imo_api.result or "[]")
        except Exception:
            return []

    def verify_imobiliare(*_):
        """Fereastra devine vizibila: TR trece verificarea site-ului ca pe un site normal, apoi o inchide."""
        threading.Thread(target=imo_open, daemon=True,   # pagina proaspata, nu cea ramasa de la ultima cautare
                         args=("https://www.imobiliare.ro/vanzare-apartamente/judetul-brasov/brasov?price=25000-80000",)).start()
        imo.set_title("Imobiliare.ro: treci verificarea, apoi închide fereastra")
        imo.show()

    def imo_closing():
        if state["quit"]:
            return True
        imo.hide()
        app.imo_verified()   # verificarea s-a facut: bara din aplicatie dispare (revine doar daca site-ul blocheaza iar)
        return False

    imo.events.closing += imo_closing
    app.VERIFY[:] = [verify_imobiliare]

    app.BROWSER["imobiliare"] = scrape_imobiliare
    threading.Thread(target=tray.run, daemon=True).start()
    storage = app.model.DATA / "webview"
    storage.mkdir(parents=True, exist_ok=True)
    webview.start(private_mode=False, storage_path=str(storage))


if __name__ == "__main__":
    main()
